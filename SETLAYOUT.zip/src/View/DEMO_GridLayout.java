package View;

import javax.swing.*;
import java.awt.*;

public class DEMO_GridLayout extends JFrame{

    public void DEMO_GridLayout() {
        this.setTitle("TEST GRIDLAYOUT");
        this.setLocationRelativeTo(null);
        this.setSize(600,450);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

        // set GridLayout

        GridLayout gridLayout = new GridLayout();//Tạo một grid layout với mặc định là một cột mỗi thành phần, trong một hàng đơn.
        GridLayout gridLayout1 = new GridLayout(4, 4); //Tạo một grid layout với các hàng và cột đã cho.
        GridLayout gridLayout2 = new GridLayout(4,4,20,20); // //Tạo một grid layout với các hàng và cột đã cho cùng với các khoảng cách theo chiều dọc và ngang đã xác định.
        this.setVisible(true);
        this.setLayout(gridLayout1);


        // set jButton
        // Tạo vào for tạo và add jButton
        for(int i = 1; i <= 16; i++)
        {
            JButton jButton = new JButton(i + " "); // bên trong ngoặc chỉ nhận dạng text nên cộng thêm khoảng trắng.
            this.add(jButton);
        }
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

    }
    }

