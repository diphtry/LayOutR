package View;

import javax.swing.*;
import java.awt.*;

public class DEMO_BorderLayout extends JFrame {
    public void DEMO_BorderLayout() {
        this.setTitle("TEST GRIDLAYOUT");
        this.setLocationRelativeTo(null);
        this.setSize(600, 450);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

        // set BorderLayout

        BorderLayout borderLayout = new BorderLayout(); // mặc định
        BorderLayout borderLayout1 = new BorderLayout(50, 50); // thêm khoảng cách
        this.setLayout(borderLayout1);

        JButton jButton = new JButton("1");
        JButton jButton1 = new JButton("2");
        JButton jButton2 = new JButton("3");
        JButton jButton3 = new JButton("4");
        JButton jButton4 = new JButton("5");

        this.add(jButton, BorderLayout.NORTH); // Hướng Bắc
        this.add(jButton1, BorderLayout.SOUTH); // Hướng Nam
        this.add(jButton2, BorderLayout.WEST); // Hướng Tây
        this.add(jButton3, BorderLayout.EAST); // hướng đông
        this.add(jButton4, BorderLayout.CENTER); // Ở giữa

    }
}


