package View;

import javax.swing.*;
import java.awt.*;

public class Demo_FlowLayout extends JFrame {
    public void Demo_FlowLayout()
    {
        this.setTitle("DEMO_FLOWLAYOUT");
        this.setSize(500,400);
        this.setLocationRelativeTo(null); // căn cửa sổ ở giữa màn hình
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);


        //SET LAYOUT


        //set Flowlayout
        FlowLayout flowLayout = new FlowLayout();
        FlowLayout F2 = new FlowLayout(FlowLayout.RIGHT); // Căn phải
        FlowLayout F3 = new FlowLayout(FlowLayout.LEFT);  // Căn trái
        FlowLayout F4 = new FlowLayout(FlowLayout.CENTER, 50, 50);  // Căn Giữa , Khoảng cách giữa các Jbutton.
        FlowLayout F5 = new FlowLayout(FlowLayout.LEADING); //
        FlowLayout F6 = new FlowLayout(FlowLayout.TRAILING);
       //this.setLayout(flowLayout);
        this.setLayout(F4);



        JButton jButton1 = new JButton("1");
        JButton jButton2 = new JButton("2");
        JButton jButton3 = new JButton("3");


       // add thành phần
        this.add(jButton1);
        this.add(jButton2);
        this.add(jButton3);

// Tạo vào for tạo và add jButton
//        for(int i = 1; i <= 25; i++) // Tạo vòng for để tạo nhiều Jbutton
//        {
//            JButton jButton = new JButton(i +  " "); // bên trong ngoặc chỉ nhận dạng text nên cộng thêm khoảng trắng.
//            this.add(jButton);
//
//        }


        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

//        this.setVisible(true);



    }

}
