import View.DEMO_BorderLayout;
import View.DEMO_GridLayout;
import View.Demo_FlowLayout;

public class Main {
    public static void main(String[] args){

//        Demo_FlowLayout D1 = new Demo_FlowLayout();
//        D1.Demo_FlowLayout();
//        DEMO_GridLayout D2 = new DEMO_GridLayout();
//        D2.DEMO_GridLayout();
        DEMO_BorderLayout D3 = new DEMO_BorderLayout();
        D3.DEMO_BorderLayout();

    }
}